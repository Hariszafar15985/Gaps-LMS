<?php return array (
  'app' => 
  array (
    'name' => 'GAPS LMS',
    'env' => 'local',
    'debug' => true,
    'url' => 'https://local.strivelh.net.au/',
    'asset_url' => NULL,
    'timezone' => 'America/New_York',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:12DLMxEkIDn7qEehOsFAG/znsORqYO82eUYM4idB+f0=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Laravel\\Socialite\\SocialiteServiceProvider',
      23 => 'Cviebrock\\EloquentSluggable\\ServiceProvider',
      24 => 'Barryvdh\\Debugbar\\ServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\AuthServiceProvider',
      27 => 'App\\Providers\\EventServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
      29 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      30 => 'Mews\\Captcha\\CaptchaServiceProvider',
      31 => 'Jorenvh\\Share\\Providers\\ShareServiceProvider',
      32 => 'KingFlamez\\Rave\\RaveServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Captcha' => 'Mews\\Captcha\\Facades\\Captcha',
      'Share' => 'Jorenvh\\Share\\ShareFacade',
      'Rave' => 'KingFlamez\\Rave\\Facades\\Rave',
      'PDF' => 'Barryvdh\\DomPDF\\Facade',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'bigbluebutton' => 
  array (
    'BBB_SECURITY_SALT' => '',
    'BBB_SERVER_BASE_URL' => '',
    'servers' => 
    array (
      'server1' => 
      array (
        'BBB_SECURITY_SALT' => '',
        'BBB_SERVER_BASE_URL' => '',
      ),
      'server2' => 
      array (
        'BBB_SECURITY_SALT' => '',
        'BBB_SERVER_BASE_URL' => '',
      ),
    ),
    'create' => 
    array (
      'passwordLength' => 8,
      'welcomeMessage' => NULL,
      'dialNumber' => NULL,
      'maxParticipants' => 0,
      'logoutUrl' => NULL,
      'record' => false,
      'duration' => 0,
      'isBreakout' => false,
      'moderatorOnlyMessage' => NULL,
      'autoStartRecording' => false,
      'allowStartStopRecording' => true,
      'webcamsOnlyForModerator' => false,
      'logo' => NULL,
      'copyright' => NULL,
      'muteOnStart' => false,
      'lockSettingsDisableCam' => false,
      'lockSettingsDisableMic' => false,
      'lockSettingsDisablePrivateChat' => false,
      'lockSettingsDisablePublicChat' => false,
      'lockSettingsDisableNote' => false,
      'lockSettingsLockedLayout' => false,
      'lockSettingsLockOnJoin' => false,
      'lockSettingsLockOnJoinConfigurable' => false,
      'guestPolicy' => 'ALWAYS_ACCEPT',
    ),
    'join' => 
    array (
      'redirect' => true,
      'joinViaHtml5' => true,
    ),
    'getRecordings' => 
    array (
      'state' => 'any',
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'gaps_lms_cache',
  ),
  'cacheKeys' => 
  array (
    'financialTabEnabled' => 'setting.financialTabEnabled',
  ),
  'captcha' => 
  array (
    'characters' => 
    array (
      0 => '2',
      1 => '3',
      2 => '4',
      3 => '6',
      4 => '7',
      5 => '8',
      6 => '9',
    ),
    'default' => 
    array (
      'length' => 5,
      'width' => 120,
      'height' => 36,
      'quality' => 90,
      'math' => false,
      'expire' => 90,
      'encrypt' => false,
    ),
    'math' => 
    array (
      'length' => 9,
      'width' => 120,
      'height' => 36,
      'quality' => 90,
      'math' => true,
    ),
    'flat' => 
    array (
      'length' => 5,
      'width' => 160,
      'height' => 40,
      'quality' => 90,
      'lines' => 6,
      'bgImage' => false,
      'bgColor' => '#ecf2f4',
      'fontColors' => 
      array (
        0 => '#2c3e50',
        1 => '#c0392b',
        2 => '#16a085',
        3 => '#c0392b',
        4 => '#8e44ad',
        5 => '#303f9f',
        6 => '#f57c00',
        7 => '#795548',
      ),
      'contrast' => -5,
    ),
    'mini' => 
    array (
      'length' => 3,
      'width' => 60,
      'height' => 32,
    ),
    'inverse' => 
    array (
      'length' => 5,
      'width' => 120,
      'height' => 36,
      'quality' => 90,
      'sensitive' => true,
      'angle' => 12,
      'sharpen' => 10,
      'blur' => 2,
      'invert' => true,
      'contrast' => -5,
    ),
  ),
  'cashu' => 
  array (
    'sandbox' => 'https://sandbox.cashu.com/secure/payment.wsdl',
    'live' => 'https://cashu.com/secure/payment.wsdl',
    'follow_sandbox' => 'https://sandbox.cashu.com/cgi-bin/payment/pcashu.cgi',
    'follow_live' => 'https://cashu.com/cgi-bin/payment/pcashu.cgi',
    'trace' => true,
    '_testmod' => '0',
    'secure' => 'default',
    '_session_id' => 'cashu',
    '_encryption_key' => '',
    '_merchant_id' => '',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'database_lms',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'database_lms',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => false,
        'engine' => NULL,
        'modes' => 
        array (
          0 => 'STRICT_ALL_TABLES',
        ),
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'database_lms',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'database_lms',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'gaps_lms_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
    ),
    'temporary_files' => 
    array (
      'local_path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\framework/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Dev\\Xampp\\htdocs\\lms\\public\\store',
        'visibility' => 'public',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Dev\\Xampp\\htdocs\\lms\\public\\store',
        'visibility' => 'public',
        'url' => '/store',
        'permissions' => 
        array (
          'file' => 
          array (
            'public' => 436,
            'private' => 384,
          ),
          'dir' => 
          array (
            'public' => 509,
            'private' => 448,
          ),
        ),
      ),
      'upload' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Dev\\Xampp\\htdocs\\lms\\public\\store',
        'url' => '/store',
        'visibility' => 'public',
        'permissions' => 
        array (
          'file' => 
          array (
            'public' => 436,
            'private' => 384,
          ),
          'dir' => 
          array (
            'public' => 509,
            'private' => 448,
          ),
        ),
      ),
      'images' => 
      array (
        'driver' => 'local',
        'root' => 'D:\\Dev\\Xampp\\htdocs\\lms\\public\\store',
        'visibility' => 'public',
        'permissions' => 
        array (
          'file' => 
          array (
            'public' => 436,
            'private' => 384,
          ),
          'dir' => 
          array (
            'public' => 509,
            'private' => 448,
          ),
        ),
      ),
      'uploadOnHost' => 
      array (
        'driver' => 'local',
        'root' => 'app',
        'visibility' => 'public',
        'permissions' => 
        array (
          'file' => 
          array (
            'public' => 436,
            'private' => 384,
          ),
          'dir' => 
          array (
            'public' => 509,
            'private' => 448,
          ),
        ),
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
      ),
    ),
    'links' => 
    array (
      'D:\\Dev\\Xampp\\htdocs\\lms\\public\\storage' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/public',
      'D:\\Dev\\Xampp\\htdocs\\lms\\public\\images' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/images',
      'D:\\Dev\\Xampp\\htdocs\\lms\\public\\bin' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/public/bin',
    ),
  ),
  'flutterwave' => 
  array (
    'publicKey' => '',
    'secretKey' => '',
    'secretHash' => '',
  ),
  'google-calendar' => 
  array (
    'default_auth_profile' => 'service_account',
    'auth_profiles' => 
    array (
      'service_account' => 
      array (
        'credentials_json' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/google-calendar/service-account-credentials.json',
      ),
      'oauth' => 
      array (
        'credentials_json' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/google-calendar/oauth-credentials.json',
        'token_json' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/google-calendar/oauth-token.json',
      ),
    ),
    'calendar_id' => NULL,
    'user_to_impersonate' => NULL,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'laravel-bitpay' => 
  array (
    'private_key' => '/tmp/bitpay.pri',
    'public_key' => '/tmp/bitpay.pub',
    'network' => 'testnet',
    'key_storage' => 'BitPayKeyUtils\\Storage\\EncryptedFilesystemStorage',
    'key_storage_password' => '',
    'token' => '',
  ),
  'laravel-share' => 
  array (
    'services' => 
    array (
      'facebook' => 
      array (
        'uri' => 'https://www.facebook.com/sharer/sharer.php?u=',
      ),
      'twitter' => 
      array (
        'uri' => 'https://twitter.com/intent/tweet',
        'text' => 'Default share text',
      ),
      'linkedin' => 
      array (
        'uri' => 'https://www.linkedin.com/sharing/share-offsite',
        'extra' => 
        array (
          'mini' => 'true',
        ),
      ),
      'whatsapp' => 
      array (
        'uri' => 'https://wa.me/?text=',
        'extra' => 
        array (
          'mini' => 'true',
        ),
      ),
      'pinterest' => 
      array (
        'uri' => 'https://pinterest.com/pin/create/button/?url=',
      ),
      'reddit' => 
      array (
        'uri' => 'https://www.reddit.com/submit',
        'text' => 'Default share text',
      ),
      'telegram' => 
      array (
        'uri' => 'https://telegram.me/share/url',
        'text' => 'Default share text',
      ),
    ),
    'fontAwesomeVersion' => 5,
  ),
  'lfm' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'App\\Handlers\\LfmConfigHandler',
    'allow_shared_folder' => false,
    'shared_folder_name' => 'shares',
    'base_directory' => '/store',
    'files_url' => '/store',
    'disk' => 'upload',
    'max_image_size' => 2097152,
    'max_file_size' => 2097152,
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => '/',
        'startup_view' => 'list',
        'max_size' => 2097152,
        'valid_mime' => 
        array (
          0 => '.pdf',
          1 => '.doc',
          2 => '.docx',
          3 => '.ppt',
          4 => '.jpeg',
          5 => '.jpg',
          6 => '.png',
          7 => '.rar',
          8 => '.zip',
          9 => '.mp4',
          10 => '.mkv',
          11 => '.avi',
          12 => '.mp3',
          13 => '.svg',
          14 => '.json',
        ),
      ),
      'image' => 
      array (
        'folder_name' => '/',
        'startup_view' => 'list',
        'max_size' => 2097152,
        'valid_mime' => 
        array (
          0 => '.pdf',
          1 => '.doc',
          2 => '.docx',
          3 => '.ppt',
          4 => '.jpeg',
          5 => '.jpg',
          6 => '.png',
          7 => '.rar',
          8 => '.zip',
          9 => '.mp4',
          10 => '.mkv',
          11 => '.avi',
          12 => '.mp3',
          13 => '.svg',
          14 => '.json',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'rename_file' => false,
    'alphanumeric_filename' => false,
    'alphanumeric_directory' => false,
    'should_validate_size' => false,
    'should_validate_mime' => false,
    'over_write_on_duplicate' => false,
    'should_create_thumbnails' => false,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\logs/laravel.log',
      ),
      'mail' => 
      array (
        'driver' => 'daily',
        'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\logs/mails/mail.log',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => '465',
        'encryption' => 'ssl',
        'username' => 'shaheermian@gmail.com',
        'password' => 'hcefspujqhxfvxbl',
        'timeout' => NULL,
        'auth_mode' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => 'shaheermian@gmail.com',
      'name' => 'GAPS LMS',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'D:\\Dev\\Xampp\\htdocs\\lms\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'organization' => 
  array (
    'contracts' => 
    array (
      0 => 'DES',
      1 => 'Jobactive',
      2 => 'TTW',
      3 => 'Parents',
      4 => 'Next',
      5 => 'Other',
    ),
  ),
  'payment' => 
  array (
    'default' => 'zarinpal',
    'drivers' => 
    array (
      'asanpardakht' => 
      array (
        'apiPurchaseUrl' => 'https://services.asanpardakht.net/paygate/merchantservices.asmx?wsdl',
        'apiPaymentUrl' => 'https://asan.shaparak.ir',
        'apiVerificationUrl' => 'https://services.asanpardakht.net/paygate/merchantservices.asmx?wsdl',
        'apiUtilsUrl' => 'https://services.asanpardakht.net/paygate/internalutils.asmx?wsdl',
        'key' => '',
        'iv' => '',
        'username' => '',
        'password' => '',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using asanpardakht',
      ),
      'behpardakht' => 
      array (
        'apiPurchaseUrl' => 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl',
        'apiPaymentUrl' => 'https://bpm.shaparak.ir/pgwchannel/startpay.mellat',
        'apiVerificationUrl' => 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl',
        'terminalId' => '',
        'username' => '',
        'password' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using behpardakht',
      ),
      'idpay' => 
      array (
        'apiPurchaseUrl' => 'https://api.idpay.ir/v1.1/payment',
        'apiPaymentUrl' => 'https://idpay.ir/p/ws/',
        'apiSandboxPaymentUrl' => 'https://idpay.ir/p/ws-sandbox/',
        'apiVerificationUrl' => 'https://api.idpay.ir/v1.1/payment/verify',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using idpay',
        'sandbox' => false,
      ),
      'irankish' => 
      array (
        'apiPurchaseUrl' => 'https://ikc.shaparak.ir/XToken/Tokens.xml',
        'apiPaymentUrl' => 'https://ikc.shaparak.ir/TPayment/Payment/index/',
        'apiVerificationUrl' => 'https://ikc.shaparak.ir/XVerify/Verify.xml',
        'merchantId' => '',
        'sha1Key' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using irankish',
      ),
      'nextpay' => 
      array (
        'apiPurchaseUrl' => 'https://api.nextpay.org/gateway/token.http',
        'apiPaymentUrl' => 'https://api.nextpay.org/gateway/payment/',
        'apiVerificationUrl' => 'https://api.nextpay.org/gateway/verify.http',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using nextpay',
      ),
      'parsian' => 
      array (
        'apiPurchaseUrl' => 'https://pec.shaparak.ir/NewIPGServices/Sale/SaleService.asmx?wsdl',
        'apiPaymentUrl' => 'https://pec.shaparak.ir/NewIPG/',
        'apiVerificationUrl' => 'https://pec.shaparak.ir/NewIPGServices/Confirm/ConfirmService.asmx?wsdl',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using parsian',
      ),
      'pasargad' => 
      array (
        'apiPaymentUrl' => 'https://pep.shaparak.ir/payment.aspx',
        'apiGetToken' => 'https://pep.shaparak.ir/Api/v1/Payment/GetToken',
        'apiCheckTransactionUrl' => 'https://pep.shaparak.ir/Api/v1/Payment/CheckTransactionResult',
        'apiVerificationUrl' => 'https://pep.shaparak.ir/Api/v1/Payment/VerifyPayment',
        'merchantId' => '',
        'terminalCode' => '',
        'certificate' => '',
        'certificateType' => 'xml_file',
        'callbackUrl' => 'http://yoursite.com/path/to',
      ),
      'payir' => 
      array (
        'apiPurchaseUrl' => 'https://pay.ir/pg/send',
        'apiPaymentUrl' => 'https://pay.ir/pg/',
        'apiVerificationUrl' => 'https://pay.ir/pg/verify/',
        'merchantId' => 'test',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using payir',
      ),
      'paypal' => 
      array (
        'apiPurchaseUrl' => 'https://www.paypal.com/cgi-bin/webscr',
        'apiPaymentUrl' => 'https://www.zarinpal.com/pg/StartPay/',
        'apiVerificationUrl' => 'https://ir.zarinpal.com/pg/services/WebGate/wsdl',
        'sandboxApiPurchaseUrl' => 'https://www.sandbox.paypal.com/cgi-bin/webscr',
        'sandboxApiPaymentUrl' => 'https://sandbox.zarinpal.com/pg/StartPay/',
        'sandboxApiVerificationUrl' => 'https://sandbox.zarinpal.com/pg/services/WebGate/wsdl',
        'mode' => 'normal',
        'currency' => '',
        'id' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using paypal',
      ),
      'payping' => 
      array (
        'apiPurchaseUrl' => 'https://api.payping.ir/v1/pay/',
        'apiPaymentUrl' => 'https://api.payping.ir/v1/pay/gotoipg/',
        'apiVerificationUrl' => 'https://api.payping.ir/v1/pay/verify/',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using payping',
      ),
      'paystar' => 
      array (
        'apiPurchaseUrl' => 'https://paystar.ir/api/create/',
        'apiPaymentUrl' => 'https://paystar.ir/paying/',
        'apiVerificationUrl' => 'https://paystar.ir/api/verify/',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using paystar',
      ),
      'poolam' => 
      array (
        'apiPurchaseUrl' => 'https://poolam.ir/invoice/request/',
        'apiPaymentUrl' => 'https://poolam.ir/invoice/pay/',
        'apiVerificationUrl' => 'https://poolam.ir/invoice/check/',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using poolam',
      ),
      'sadad' => 
      array (
        'apiPurchaseUrl' => 'https://sadad.shaparak.ir/vpg/api/v0/Request/PaymentRequest',
        'apiPaymentUrl' => 'https://sadad.shaparak.ir/VPG/Purchase',
        'apiVerificationUrl' => 'https://sadad.shaparak.ir/VPG/api/v0/Advice/Verify',
        'key' => '',
        'merchantId' => '',
        'terminalId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using sadad',
      ),
      'saman' => 
      array (
        'apiPurchaseUrl' => 'https://sep.shaparak.ir/Payments/InitPayment.asmx?WSDL',
        'apiPaymentUrl' => 'https://sep.shaparak.ir/payment.aspx',
        'apiVerificationUrl' => 'https://sep.shaparak.ir/payments/referencepayment.asmx?WSDL',
        'merchantId' => '',
        'callbackUrl' => '',
        'description' => 'payment using saman',
      ),
      'sepehr' => 
      array (
        'apiGetToken' => 'https://mabna.shaparak.ir:8081/V1/PeymentApi/GetToken',
        'apiPaymentUrl' => 'https://mabna.shaparak.ir:8080/pay',
        'apiVerificationUrl' => 'https://mabna.shaparak.ir:8081/V1/PeymentApi/Advice',
        'terminalId' => '',
        'callbackUrl' => '',
        'description' => 'payment using sepehr(saderat)',
      ),
      'yekpay' => 
      array (
        'apiPurchaseUrl' => 'https://gate.yekpay.com/api/payment/server?wsdl',
        'apiPaymentUrl' => 'https://gate.yekpay.com/api/payment/start/',
        'apiVerificationUrl' => 'https://gate.yekpay.com/api/payment/server?wsdl',
        'fromCurrencyCode' => 978,
        'toCurrencyCode' => 364,
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using yekpay',
      ),
      'zarinpal' => 
      array (
        'apiPurchaseUrl' => 'https://ir.zarinpal.com/pg/services/WebGate/wsdl',
        'apiPaymentUrl' => 'https://www.zarinpal.com/pg/StartPay/',
        'apiVerificationUrl' => 'https://ir.zarinpal.com/pg/services/WebGate/wsdl',
        'sandboxApiPurchaseUrl' => 'https://sandbox.zarinpal.com/pg/services/WebGate/wsdl',
        'sandboxApiPaymentUrl' => 'https://sandbox.zarinpal.com/pg/StartPay/',
        'sandboxApiVerificationUrl' => 'https://sandbox.zarinpal.com/pg/services/WebGate/wsdl',
        'zaringateApiPurchaseUrl' => 'https://ir.zarinpal.com/pg/services/WebGate/wsdl',
        'zaringateApiPaymentUrl' => 'https://www.zarinpal.com/pg/StartPay/:authority/ZarinGate',
        'zaringateApiVerificationUrl' => 'https://ir.zarinpal.com/pg/services/WebGate/wsdl',
        'mode' => 'sandbox',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using zarinpal',
      ),
      'zibal' => 
      array (
        'apiPurchaseUrl' => 'https://gateway.zibal.ir/v1/request',
        'apiPaymentUrl' => 'https://gateway.zibal.ir/start/',
        'apiVerificationUrl' => 'https://gateway.zibal.ir/v1/verify',
        'mode' => 'normal',
        'merchantId' => '',
        'callbackUrl' => 'http://yoursite.com/path/to',
        'description' => 'payment using zibal',
      ),
    ),
    'map' => 
    array (
      'asanpardakht' => 'Shetabit\\Multipay\\Drivers\\Asanpardakht\\Asanpardakht',
      'behpardakht' => 'Shetabit\\Multipay\\Drivers\\Behpardakht\\Behpardakht',
      'idpay' => 'Shetabit\\Multipay\\Drivers\\Idpay\\Idpay',
      'irankish' => 'Shetabit\\Multipay\\Drivers\\Irankish\\Irankish',
      'nextpay' => 'Shetabit\\Multipay\\Drivers\\Nextpay\\Nextpay',
      'parsian' => 'Shetabit\\Multipay\\Drivers\\Parsian\\Parsian',
      'pasargad' => 'Shetabit\\Multipay\\Drivers\\Pasargad\\Pasargad',
      'payir' => 'Shetabit\\Multipay\\Drivers\\Payir\\Payir',
      'paypal' => 'Shetabit\\Multipay\\Drivers\\Paypal\\Paypal',
      'payping' => 'Shetabit\\Multipay\\Drivers\\Payping\\Payping',
      'paystar' => 'Shetabit\\Multipay\\Drivers\\Paystar\\Paystar',
      'poolam' => 'Shetabit\\Multipay\\Drivers\\Poolam\\Poolam',
      'sadad' => 'Shetabit\\Multipay\\Drivers\\Sadad\\Sadad',
      'saman' => 'Shetabit\\Multipay\\Drivers\\Saman\\Saman',
      'sepehr' => 'Shetabit\\Multipay\\Drivers\\Sepehr\\Sepehr',
      'yekpay' => 'Shetabit\\Multipay\\Drivers\\Yekpay\\Yekpay',
      'zarinpal' => 'Shetabit\\Multipay\\Drivers\\Zarinpal\\Zarinpal',
      'zibal' => 'Shetabit\\Multipay\\Drivers\\Zibal\\Zibal',
    ),
  ),
  'paypal' => 
  array (
    'client_id' => '',
    'secret' => '',
    'currency' => 'USD',
    'settings' => 
    array (
      'mode' => 'sandbox',
      'http.ConnectionTimeOut' => 30,
      'log.LogEnabled' => true,
      'log.FileName' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage/logs/paypal.log',
      'log.LogLevel' => 'ERROR',
    ),
  ),
  'paystack' => 
  array (
    'publicKey' => '',
    'secretKey' => '',
    'paymentUrl' => 'https://api.paystack.co',
    'merchantEmail' => '',
  ),
  'payu' => 
  array (
    'default' => 'money',
    'gateways' => 
    array (
      'money' => 
      Tzsk\Payu\Gateway\PayuMoney::__set_state(array(
         'key' => '',
         'salt' => '',
         'auth' => '',
         'base' => 'payu.in',
         'serviceProvider' => 'payu_paisa',
         'processUrls' => 
        array (
          'test' => 'https://sandboxsecure.%s/_payment',
          'live' => 'https://secure.%s/_payment',
        ),
         'mode' => 'test',
      )),
      'biz' => 
      Tzsk\Payu\Gateway\PayuBiz::__set_state(array(
         'key' => 'gtKFFx',
         'salt' => 'eCwWELxi',
         'base' => 'payu.in',
         'processUrls' => 
        array (
          'test' => 'https://test.%s/_payment',
          'live' => 'https://secure.%s/_payment',
        ),
         'mode' => 'test',
      )),
    ),
    'verify' => 
    array (
      0 => 'pending',
    ),
  ),
  'purifier' => 
  array (
    'encoding' => 'UTF-8',
    'finalize' => true,
    'ignoreNonStrings' => false,
    'cachePath' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\app/purifier',
    'cacheFileMode' => 493,
    'settings' => 
    array (
      'default' => 
      array (
        'HTML.Doctype' => 'HTML 4.01 Transitional',
        'HTML.Allowed' => 'div,b,strong,i,em,u,a[href|title],ul,ol,li,p[style],br,span[style],img[width|height|alt|src]',
        'CSS.AllowedProperties' => 'font,font-size,font-weight,font-style,font-family,text-decoration,padding-left,color,background-color,text-align',
        'AutoFormat.AutoParagraph' => true,
        'AutoFormat.RemoveEmpty' => true,
      ),
      'test' => 
      array (
        'Attr.EnableID' => 'true',
      ),
      'youtube' => 
      array (
        'HTML.SafeIframe' => 'true',
        'URI.SafeIframeRegexp' => '%^(http://|https://|//)(www.youtube.com/embed/|player.vimeo.com/video/)%',
      ),
      'custom_definition' => 
      array (
        'id' => 'html5-definitions',
        'rev' => 1,
        'debug' => false,
        'elements' => 
        array (
          0 => 
          array (
            0 => 'section',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          1 => 
          array (
            0 => 'nav',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          2 => 
          array (
            0 => 'article',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          3 => 
          array (
            0 => 'aside',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          4 => 
          array (
            0 => 'header',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          5 => 
          array (
            0 => 'footer',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          6 => 
          array (
            0 => 'address',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
          ),
          7 => 
          array (
            0 => 'hgroup',
            1 => 'Block',
            2 => 'Required: h1 | h2 | h3 | h4 | h5 | h6',
            3 => 'Common',
          ),
          8 => 
          array (
            0 => 'figure',
            1 => 'Block',
            2 => 'Optional: (figcaption, Flow) | (Flow, figcaption) | Flow',
            3 => 'Common',
          ),
          9 => 
          array (
            0 => 'figcaption',
            1 => 'Inline',
            2 => 'Flow',
            3 => 'Common',
          ),
          10 => 
          array (
            0 => 'video',
            1 => 'Block',
            2 => 'Optional: (source, Flow) | (Flow, source) | Flow',
            3 => 'Common',
            4 => 
            array (
              'src' => 'URI',
              'type' => 'Text',
              'width' => 'Length',
              'height' => 'Length',
              'poster' => 'URI',
              'preload' => 'Enum#auto,metadata,none',
              'controls' => 'Bool',
            ),
          ),
          11 => 
          array (
            0 => 'source',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'src' => 'URI',
              'type' => 'Text',
            ),
          ),
          12 => 
          array (
            0 => 's',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          13 => 
          array (
            0 => 'var',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          14 => 
          array (
            0 => 'sub',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          15 => 
          array (
            0 => 'sup',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          16 => 
          array (
            0 => 'mark',
            1 => 'Inline',
            2 => 'Inline',
            3 => 'Common',
          ),
          17 => 
          array (
            0 => 'wbr',
            1 => 'Inline',
            2 => 'Empty',
            3 => 'Core',
          ),
          18 => 
          array (
            0 => 'ins',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'cite' => 'URI',
              'datetime' => 'CDATA',
            ),
          ),
          19 => 
          array (
            0 => 'del',
            1 => 'Block',
            2 => 'Flow',
            3 => 'Common',
            4 => 
            array (
              'cite' => 'URI',
              'datetime' => 'CDATA',
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            0 => 'iframe',
            1 => 'allowfullscreen',
            2 => 'Bool',
          ),
          1 => 
          array (
            0 => 'table',
            1 => 'height',
            2 => 'Text',
          ),
          2 => 
          array (
            0 => 'td',
            1 => 'border',
            2 => 'Text',
          ),
          3 => 
          array (
            0 => 'th',
            1 => 'border',
            2 => 'Text',
          ),
          4 => 
          array (
            0 => 'tr',
            1 => 'width',
            2 => 'Text',
          ),
          5 => 
          array (
            0 => 'tr',
            1 => 'height',
            2 => 'Text',
          ),
          6 => 
          array (
            0 => 'tr',
            1 => 'border',
            2 => 'Text',
          ),
        ),
      ),
      'custom_attributes' => 
      array (
        0 => 
        array (
          0 => 'a',
          1 => 'target',
          2 => 'Enum#_blank,_self,_target,_top',
        ),
      ),
      'custom_elements' => 
      array (
        0 => 
        array (
          0 => 'u',
          1 => 'Inline',
          2 => 'Inline',
          3 => 'Common',
        ),
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'suffix' => NULL,
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'google' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => '/google/callback',
    ),
    'facebook' => 
    array (
      'client_id' => '',
      'client_secret' => '',
      'redirect' => '/facebook/callback',
    ),
    'bank_callback_token' => '',
    'paytm-wallet' => 
    array (
      'env' => 'local',
      'merchant_id' => '',
      'merchant_key' => '',
      'merchant_website' => 'WEBSTAGING',
      'channel' => 'WEB',
      'industry_type' => 'Retail',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'gaps_lms_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'sluggable' => 
  array (
    'source' => NULL,
    'maxLength' => NULL,
    'maxLengthKeepWords' => true,
    'method' => 
    Closure::__set_state(array(
    )),
    'separator' => '-',
    'unique' => true,
    'uniqueSuffix' => NULL,
    'includeTrashed' => false,
    'reserved' => NULL,
    'onUpdate' => false,
  ),
  'students' => 
  array (
    'titles' => 
    array (
      1 => 'Mr',
      2 => 'Mrs',
      3 => 'Miss',
      4 => 'Dr',
    ),
    'genders' => 
    array (
      1 => 'Male',
      2 => 'Female',
      3 => 'Unspecified',
    ),
    'cultural_identities' => 
    array (
      1 => 'Aboriginal',
      2 => 'Torres Strait Islander (TSI)',
      3 => 'Both Aboriginal and TSI',
      4 => 'Neither',
    ),
    'citizenships' => 
    array (
      1 => 'Australia Citizen',
      2 => 'Permanent Resident',
      3 => 'New Zealand Resident',
      4 => 'Other, Visa Type',
    ),
    'disabilities' => 
    array (
      1 => 'Hearing/Deaf',
      2 => 'Physical',
      3 => 'Intellectual',
      4 => 'Vision',
      5 => 'Aquired Brain Impairment',
      6 => 'Mental Illness',
      7 => 'Learning',
      8 => 'Medical Condition',
    ),
    'employment_types' => 
    array (
      1 => 'Full-time Employee',
      2 => 'Part-time Employee',
      3 => 'Self-employed - not employing others',
      4 => 'Self-employed - employing others',
      5 => 'Employed - unpaid worker in a family business',
      6 => 'Unemployed - seeking full-time work',
      7 => 'Unemployed - seeking part-time work',
      8 => 'Not Employed - not seeking employment',
    ),
    'school_levels' => 
    array (
      1 => 'Year 12',
      2 => 'Year 11',
      3 => 'Year 10',
      4 => 'Year 9',
      5 => 'Year 8 or below',
      6 => 'Never attended',
    ),
    'study_reasons' => 
    array (
      1 => 'To get a job',
      2 => 'To develop my existing business',
      3 => 'To start my own business',
      4 => 'To get into another course of study',
      5 => 'To try for a different career',
      6 => 'To get a better job or promotion',
      7 => 'It was a requirement of my job',
      8 => 'I wanted extra skills for my job',
      9 => 'For personal interest or self-development',
      10 => 'To get skills for community/voluntary work',
      11 => 'Other reasons',
    ),
    'document_types' => 
    array (
      0 => 'Resume',
      1 => 'Invoice',
      2 => 'Enrollment',
      3 => 'Certificate',
      4 => 'Notice',
      5 => 'Letter',
      6 => 'Request',
    ),
  ),
  'translatable' => 
  array (
    'locales' => 
    array (
      0 => 'en',
      1 => 'fr',
      'es' => 
      array (
        0 => 'MX',
        1 => 'CO',
      ),
    ),
    'locale_separator' => '-',
    'locale' => NULL,
    'use_fallback' => false,
    'use_property_fallback' => true,
    'fallback_locale' => 'en',
    'translation_model_namespace' => 'App\\Models\\Translation',
    'translation_suffix' => 'Translation',
    'locale_key' => 'locale',
    'to_array_always_loads_translations' => true,
    'rule_factory' => 
    array (
      'format' => 1,
      'prefix' => '%',
      'suffix' => '%',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'D:\\Dev\\Xampp\\htdocs\\lms\\resources\\views',
    ),
    'compiled' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\framework\\views',
  ),
  'xero' => 
  array (
    'clientId' => 'F4845C5F1BFA429BBCD7D010588CF904',
    'clientSecret' => 'PcT4e7rdxpp-KB0HHwBuNpSClIJ1pnCni-1Ji090WNTeLa6T',
    'redirectUri' => 'https://127.0.0.1:8000/xero/connect',
    'landingUri' => 'https://127.0.0.1:8000/xero',
    'accessToken' => '',
    'webhookKey' => 'IkY9NAt9YibJ7qdJuVlhFY8Glrajxn7gNWcnvxSLO8MEb/Tar9UWhNaLz98JvhzUx/uOUrOgpQEaSItyPqRDhg==',
    'scopes' => 'openid email profile offline_access accounting.settings accounting.transactions accounting.contacts',
  ),
  'zoom' => 
  array (
    'api_key' => '',
    'api_secret' => '',
    'base_url' => 'https://api.zoom.us/v2/',
    'token_life' => 604800,
    'authentication_method' => 'jwt',
    'max_api_calls_per_request' => '5',
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\debugbar',
      'connection' => NULL,
      'provider' => '',
      'hostname' => '127.0.0.1',
      'port' => 2304,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
      'livewire' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'backtrace_exclude_paths' => 
        array (
        ),
        'timeline' => false,
        'duration_background' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => false,
        'show_copy' => false,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'timeline' => false,
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'orientation' => 'portrait',
    'convert_entities' => true,
    'defines' => 
    array (
      'font_dir' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\fonts',
      'font_cache' => 'D:\\Dev\\Xampp\\htdocs\\lms\\storage\\fonts',
      'temp_dir' => 'D:\\Dev\\Xampp\\tmp',
      'chroot' => 'D:\\Dev\\Xampp\\htdocs\\lms',
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => false,
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
      'report_logs' => true,
      'maximum_number_of_collected_logs' => 200,
      'censor_request_body_fields' => 
      array (
        0 => 'password',
      ),
    ),
    'send_logs_as_events' => true,
    'censor_request_body_fields' => 
    array (
      0 => 'password',
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'lfm-config' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'UniSharp\\LaravelFilemanager\\Handlers\\ConfigHandler',
    'allow_shared_folder' => true,
    'shared_folder_name' => 'shares',
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => 'files',
        'startup_view' => 'list',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'application/pdf',
          5 => 'text/plain',
        ),
      ),
      'image' => 
      array (
        'folder_name' => 'photos',
        'startup_view' => 'grid',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'disk' => 'public',
    'rename_file' => false,
    'rename_duplicates' => false,
    'alphanumeric_filename' => false,
    'alphanumeric_directory' => false,
    'should_validate_size' => false,
    'should_validate_mime' => true,
    'over_write_on_duplicate' => false,
    'disallowed_mimetypes' => 
    array (
      0 => 'text/x-php',
      1 => 'text/html',
      2 => 'text/plain',
    ),
    'item_columns' => 
    array (
      0 => 'name',
      1 => 'url',
      2 => 'time',
      3 => 'icon',
      4 => 'is_file',
      5 => 'is_image',
      6 => 'thumb_url',
    ),
    'should_create_thumbnails' => true,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 94,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
